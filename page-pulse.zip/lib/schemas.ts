import { z } from 'zod';

export const leadSchema = z.object({
  name: z.string().min(2, { message: 'Name must be at least 2 characters' }),
  email: z.string().email({ message: 'Please enter a valid email address' }),
  company: z.string().optional(),
  phone: z.string().optional(),
  source: z.string().optional().default('Website Landing Page'),
  message: z.string().min(5, { message: 'Message must be at least 5 characters long' }),
});

export type LeadPayload = z.infer<typeof leadSchema>;

export const loginSchema = z.object({
  email: z.string().email({ message: 'Valid email is required' }),
  password: z.string().min(6, { message: 'Password must be at least 6 characters' }),
});

export type LoginPayload = z.infer<typeof loginSchema>;
